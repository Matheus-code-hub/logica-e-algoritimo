// Não esquecer de instalar (Para poder simular):
// npm install prompt-sync

const prompt = require('prompt-sync')();

const nomes = [];
const notas1 = [];
const notas2 = [];
const frequencias = [];

const TOTAL_ALUNOS = 3;

// ==========================================
// ETAPA 2 — FUNÇÕES (Com retorno)
// ==========================================

// Função para calcular e retornar a média aritmética
function calculaMedia(nota1, nota2) {
    return (nota1 + nota2) / 2;
}

// Função para verificar e retornar a situação do aluno
function verificaSituacao(media, frequencia) {
    if (media >= 7.0 && frequencia >= 75) {
        return "Aprovado";
    } else if (media >= 4.0 && frequencia >= 75) {
        return "Recuperação";
    } else {
        return "Reprovado";
    }
}

// ==========================================
// ETAPA 3 — PROCEDIMENTOS (Sem retorno)
// ==========================================

// Procedimento para exibir o boletim detalhado de cada aluno
function exibeBoletim(nome, n1, n2, freq, media, situacao, indice) {
    console.log(`\n BOLETIM — Aluno ${indice + 1} `);
    console.log(`  Nome:        ${nome}`);
    console.log(`  Nota 1:      ${n1.toFixed(1)}`);
    console.log(`  Nota 2:      ${n2.toFixed(1)}`);
    console.log(`  Frequência:  ${freq}%`);
    console.log(`  Média:       ${media.toFixed(1)}`);
    console.log(`  Situação:    ${situacao}`);
    console.log("==========================================");
}

// Procedimento para exibir o resumo estatístico final da turma
function exibeResumo(aprovados, recuperacao, reprovados) {
    console.log("\nRESUMO GERAL DA TURMA");
    console.log(`  Aprovados:       ${aprovados}`);
    console.log(`  Recuperação:     ${recuperacao}`);
    console.log(`  Reprovados:      ${reprovados}`);
}

// ==========================================
// ETAPA 1 — CADASTRO AND EXECUÇÃO PRINCIPAL
// ==========================================
function executarGerenciador() {
    console.log("--- INICIANDO CADASTRO DE ALUNOS ---");
    
    // Laço Loop para entrada de dados
    for (let i = 0; i < TOTAL_ALUNOS; i++) {
        // Captura de dados via prompt do navegador (converte notas e faltas para números)
        let nome = prompt(`Digite o nome do aluno ${i + 1}:`);
        let n1 = parseFloat(prompt(`Digite a Nota 1 de ${nome}:`));
        let n2 = parseFloat(prompt(`Digite a Nota 2 de ${nome}:`));
        let freq = parseFloat(prompt(`Digite a Frequência (%) de ${nome}:`));
        
        // Armazenamento nos vetores paralelos
        nomes.push(nome);
        notas1.push(n1);
        notas2.push(n2);
        frequencias.push(freq);
    }

    // Variáveis contadoras acumuladas para o resumo
    let totalAprovados = 0;
    let totalRecuperacao = 0;
    let totalReprovados = 0;

    console.log("\n==========================================");
    console.log("         PROCESSANDO BOLETINS             ");
    console.log("==========================================");

    // Laço Loop para processamento e exibição
    for (let i = 0; i < TOTAL_ALUNOS; i++) {
        // Chamada das funções de cálculo
        let mediaFinal = calculaMedia(notas1[i], notas2[i]);
        let situacaoFinal = verificaSituacao(mediaFinal, frequencias[i]);

        // Estrutura condicional encadeada para incrementar os contadores
        if (situacaoFinal === "Aprovado") {
            totalAprovados++;
        } else if (situacaoFinal === "Recuperação") {
            totalRecuperacao++;
        } else {
            totalReprovados++;
        }

        // Chamada do procedimento de exibição do boletim individual
        exibeBoletim(nomes[i], notas1[i], notas2[i], frequencias[i], mediaFinal, situacaoFinal, i);
    }

    // Chamada do procedimento de exibição do resumo final
    exibeResumo(totalAprovados, totalRecuperacao, totalReprovados);
}

// Executa o programa principal
executarGerenciador();